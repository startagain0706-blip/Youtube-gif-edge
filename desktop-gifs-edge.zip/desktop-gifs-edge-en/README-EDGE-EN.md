# YouTube GIF Helper — Microsoft Edge (English)

## Install
1. Download and extract the ZIP file.
2. Open `edge://extensions` in Microsoft Edge.
3. Turn on **Developer mode**.
4. Select **Load unpacked** and choose the extracted `youtube-gif-helper-edge-en` folder.
5. Refresh YouTube.

## Features
- **Comments:** Select a GIF with the GIF button in a YouTube comment box. Review the comment before posting.
- **Live chat:** Select a GIF to insert its Tenor link into the live-chat input. Review and send it yourself.
- **Favorites:** Use the star button to save or remove favorite GIFs.

## Live chat limitation
YouTube live chat does not support inserting arbitrary animated GIF files directly into regular messages. This extension inserts a Tenor link instead; it cannot guarantee the GIF will animate inline in chat.

## Privacy and security notes
- GIF search sends requests to Tenor services.
- Comment GIF posting depends on YouTube's page behavior and may break after YouTube updates.
- Review links before sending them.
- This package has been translated and syntax-checked; that does not guarantee that it is free of all malware or that every feature works in every Edge version.
